from django.contrib import admin
from text.models import User_Detail

# Register your models here.

admin.site.register(User_Detail)
