from django.apps import AppConfig


class TextConfig(AppConfig):
    name = 'text'
