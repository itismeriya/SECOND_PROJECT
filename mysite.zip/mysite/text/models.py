from django.db import models
from django.contrib.auth.forms import UserCreationForm
# Create your models here.
from django.contrib.auth import authenticate, login, logout


class User_Detail(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    email = models.CharField(max_length=100)

    #def str(self):
     #   return self.username
