from django.shortcuts import render,redirect
from text.models import User_Detail
from django.contrib.auth import authenticate, login, logout
# Create your views here.

def index(request):
    if request.method == "POST":
        user = request.POST.get('iuser')
        email = request.POST.get('email')

        if request.POST.get('ipass') == request.POST.get('rpass'):
            pas = request.POST.get('ipass')
    
        user_details = User_Detail(username=user, password=pas, email=email)
        user_details.save()

    return render(request, 'index.html')


def homepage(request):
    return render(request, 'homepage.html')
